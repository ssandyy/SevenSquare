
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Images, Trash2, Download, Eye } from 'lucide-react';
import { toast } from 'sonner';

interface SavedDesign {
  id: string;
  name: string;
  timestamp: Date;
  imageData: string;
  color: string;
  pattern: string;
}

interface DesignGalleryProps {
  savedDesigns: SavedDesign[];
  onDeleteDesign: (id: string) => void;
  onDownloadDesign: (design: SavedDesign) => void;
}

const DesignGallery: React.FC<DesignGalleryProps> = ({
  savedDesigns,
  onDeleteDesign,
  onDownloadDesign
}) => {
  const [selectedDesign, setSelectedDesign] = useState<string | null>(null);
  const [previewDesign, setPreviewDesign] = useState<SavedDesign | null>(null);

  const handleDeleteDesign = (id: string) => {
    onDeleteDesign(id);
    toast.success('Design deleted successfully!');
  };

  const handleDownloadDesign = (design: SavedDesign) => {
    onDownloadDesign(design);
    toast.success('Design downloaded!');
  };

  return (
    <Card className="bg-white/10 backdrop-blur-lg border-white/20">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Images className="w-5 h-5" />
          Design Gallery ({savedDesigns.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        {savedDesigns.length === 0 ? (
          <div className="text-center py-8 text-gray-400">
            <Images className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No saved designs yet</p>
            <p className="text-sm">Create and save your first nail art design!</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-64 overflow-y-auto">
            {savedDesigns.map((design) => (
              <div
                key={design.id}
                className={`bg-white/5 rounded-lg p-3 cursor-pointer transition-all ${
                  selectedDesign === design.id ? 'ring-2 ring-blue-500' : 'hover:bg-white/10'
                }`}
                onClick={() => setSelectedDesign(design.id)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-white font-medium text-sm">{design.name}</h4>
                      <Badge
                        style={{ backgroundColor: design.color }}
                        className="text-xs px-2 py-0"
                      >
                        {design.pattern}
                      </Badge>
                    </div>
                    <p className="text-xs text-gray-400">
                      {design.timestamp.toLocaleDateString()} at {design.timestamp.toLocaleTimeString()}
                    </p>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        setPreviewDesign(design);
                      }}
                      className="h-8 w-8 p-0 text-green-400 hover:bg-green-500/20"
                    >
                      <Eye className="w-3 h-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDownloadDesign(design);
                      }}
                      className="h-8 w-8 p-0 text-blue-400 hover:bg-blue-500/20"
                    >
                      <Download className="w-3 h-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteDesign(design.id);
                      }}
                      className="h-8 w-8 p-0 text-red-400 hover:bg-red-500/20"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
      
      {/* Preview Modal */}
      {previewDesign && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setPreviewDesign(null)}
        >
          <div 
            className="bg-white/10 backdrop-blur-lg border border-white/20 rounded-lg p-6 max-w-lg w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white text-lg font-semibold">Design Preview</h3>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setPreviewDesign(null)}
                className="text-white hover:bg-white/20"
              >
                ✕
              </Button>
            </div>
            
            <div className="space-y-4">
              <div className="bg-white/5 rounded-lg p-4">
                <img 
                  src={previewDesign.imageData} 
                  alt={previewDesign.name}
                  className="w-full h-64 object-contain rounded border border-white/10"
                />
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-gray-400 text-sm">Design:</span>
                  <span className="text-white font-medium">{previewDesign.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-gray-400 text-sm">Pattern:</span>
                  <Badge
                    style={{ backgroundColor: previewDesign.color }}
                    className="text-xs"
                  >
                    {previewDesign.pattern}
                  </Badge>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-gray-400 text-sm">Created:</span>
                  <span className="text-white text-sm">
                    {previewDesign.timestamp.toLocaleDateString()} at {previewDesign.timestamp.toLocaleTimeString()}
                  </span>
                </div>
              </div>
              
              <div className="flex gap-2 pt-4">
                <Button
                  onClick={() => handleDownloadDesign(previewDesign)}
                  className="flex-1"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
                <Button
                  onClick={() => handleDeleteDesign(previewDesign.id)}
                  variant="destructive"
                  className="flex-1"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </Card>
  );
};

export default DesignGallery;
