import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Eye, Palette } from 'lucide-react';
import React from 'react';

interface DesignPreviewProps {
  selectedColor: string;
  selectedPattern: string;
  patternColor: string;
}

const DesignPreview: React.FC<DesignPreviewProps> = ({
  selectedColor,
  selectedPattern,
  patternColor
}) => {
  // Pattern rendering functions
  const renderPattern = (pattern: string, color: string) => {
    const patternProps = {
      width: "100%",
      height: "100%",
      fill: color
    };

    switch (pattern) {
      case 'Polka Dots':
        return (
          <pattern id="polka-dots" patternUnits="userSpaceOnUse" width="20" height="20">
            <circle cx="10" cy="10" r="3" fill={color} />
          </pattern>
        );
      case 'French Tip':
  return (
    <pattern id="french" patternUnits="userSpaceOnUse" width="80" height="100">
      <rect x="0" y="0" width="80"  fill={selectedColor} />
      <rect x="0" y="0" width="80" height="30" fill="#ffffff" />
    </pattern>
  );

      case 'Stripes':
        return (
          <pattern id="stripes" patternUnits="userSpaceOnUse" width="10" height="10">
            <rect width="5" height="100%" fill={color} />
          </pattern>
        );
      case 'Floral':
        return (
          <pattern id="floral" patternUnits="userSpaceOnUse" width="30" height="30">
            <circle cx="15" cy="15" r="3" fill={color} />
            {[...Array(5)].map((_, i) => {
              const angle = (i * 72 * Math.PI) / 180;
              return (
                <circle
                  key={i}
                  cx={15 + Math.cos(angle) * 6}
                  cy={15 + Math.sin(angle) * 6}
                  r="2"
                  fill={color}
                />
              );
            })}
          </pattern>
        );
      case 'Glitter':
        return (
          <pattern id="glitter" patternUnits="userSpaceOnUse" width="10" height="10">
            <circle cx="2" cy="2" r="1" fill={color} />
            <circle cx="7" cy="5" r="0.5" fill={color} />
          </pattern>
        );
      case 'Gradient':
        return (
          <linearGradient id="gradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={selectedColor} />
            <stop offset="100%" stopColor="#ffffff" />
          </linearGradient>
        );
      case 'Ombre':
        return (
          <linearGradient id="ombre" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={selectedColor} />
            <stop offset="50%" stopColor={`${selectedColor}80`} />
            <stop offset="100%" stopColor="#ffffff" />
          </linearGradient>
        );
      case 'Checkerboard':
        return (
          <pattern id="checkerboard" width="10" height="10" patternUnits="userSpaceOnUse">
            <rect x="0" y="0" width="5" height="5" fill={color} />
            <rect x="5" y="5" width="5" height="5" fill={color} />
          </pattern>
        );
      case 'Hearts':
        return (
          <pattern id="hearts" width="20" height="20" patternUnits="userSpaceOnUse">
            <path
              d="M10 3
               C10 0, 14 0, 14 3
               C14 6, 10 9, 10 9
               C10 9, 6 6, 6 3
               C6 0, 10 0, 10 3Z"
              fill={color}
            />
          </pattern>
        );
      case 'Stars':
        return (
          <pattern id="stars" width="20" height="20" patternUnits="userSpaceOnUse">
            <polygon
              points="10,1 12,7 18,7 13,11 15,17 10,13 5,17 7,11 2,7 8,7"
              fill={color}
            />
          </pattern>
        );
      case 'Geometric':
        return (
          <pattern id="geometric" width="16" height="16" patternUnits="userSpaceOnUse">
            <polygon points="8,2 14,8 8,14 2,8" fill={color} />
          </pattern>
        );
      case 'Animal Print':
        return (
          <pattern id="animal" width="20" height="20" patternUnits="userSpaceOnUse">
            <ellipse cx="10" cy="10" rx="4" ry="2" fill={color} transform="rotate(45 10 10)" />
            <ellipse cx="5" cy="15" rx="3" ry="1.5" fill={color} transform="rotate(-30 5 15)" />
          </pattern>
        );
      case 'Lace':
        return (
          <pattern id="lace" width="12" height="12" patternUnits="userSpaceOnUse">
            <circle cx="6" cy="6" r="1" fill={color} />
            <path d="M6,2 Q9,6 6,10 Q3,6 6,2" fill="none" stroke={color} strokeWidth="0.5" />
          </pattern>
        );
      case 'Swirls':
        return (
          <pattern id="swirls" width="20" height="20" patternUnits="userSpaceOnUse">
            <path
              d="M0,10 Q10,0 20,10 T40,10"
              fill="none"
              stroke={color}
              strokeWidth="1"
            />
          </pattern>
        );
      case 'Zigzag':
        return (
          <pattern id="zigzag" width="20" height="10" patternUnits="userSpaceOnUse">
            <polyline points="0,10 5,0 10,10 15,0 20,10" fill="none" stroke={color} strokeWidth="1" />
          </pattern>
        );
      case 'Tribal':
        return (
          <pattern id="tribal" width="20" height="20" patternUnits="userSpaceOnUse">
            <line x1="10" y1="0" x2="10" y2="20" stroke={color} strokeWidth="2" />
            <circle cx="10" cy="10" r="2" fill={color} />
          </pattern>
        );

      default:
        return null;
    }
  };

  const getPatternFill = (pattern: string): string => {
    const id = pattern.toLowerCase().replace(/ /g, '-');
    return pattern === 'Solid' ? selectedColor : `url(#${id})`;
  };

  return (
    <Card className="bg-white/10 backdrop-blur-lg border-white/20">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Eye className="w-5 h-5" />
          Design Preview
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Nail Preview */}
        <div className="flex justify-center">
          <div className="relative">
            <svg width="80" height="100" viewBox="0 0 80 100" className="drop-shadow-lg">
              <defs>
                {renderPattern(selectedPattern, patternColor)}
              </defs>
              {/* Nail base */}
              <ellipse
                cx="40"
                cy="75"
                rx="25"
                ry="35"
                fill={selectedColor}
                stroke="rgba(255,255,255,0.3)"
                strokeWidth="1"
                opacity="0.8"
              />
              {/* Pattern overlay */}
              {selectedPattern !== 'Solid' && (
                <ellipse
                  cx="40"
                  cy="75"
                  rx="25"
                  ry="35"
                  fill={getPatternFill(selectedPattern)}
                  opacity="0.8"
                />
              )}
            </svg>
          </div>
        </div>

        {/* Selected Options */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-gray-300 text-sm">Base Color:</span>
            <Badge variant="outline" className="text-white border-white/20">
              <div
                className="w-3 h-3 rounded-full mr-2"
                style={{ backgroundColor: selectedColor }}
              />
              {selectedColor}
            </Badge>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-gray-300 text-sm">Pattern:</span>
            <Badge variant="outline" className="text-white border-white/20">
              <Palette className="w-3 h-3 mr-2" />
              {selectedPattern}
            </Badge>
          </div>

          {selectedPattern !== 'Solid' && (
            <div className="flex items-center justify-between">
              <span className="text-gray-300 text-sm">Pattern Color:</span>
              <Badge variant="outline" className="text-white border-white/20">
                <div
                  className="w-3 h-3 rounded-full mr-2"
                  style={{ backgroundColor: patternColor }}
                />
                {patternColor}
              </Badge>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default DesignPreview;