import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Palette, Save, Sparkles } from 'lucide-react';
import React, { useEffect, useState } from 'react';

interface NailRegion {
  x: number;
  y: number;
  width: number;
  height: number;
  confidence: number;
  fingerId: number;
}

interface VirtualNailArtProps {
  canvasRef: React.RefObject<HTMLCanvasElement>;
  detectedNails: NailRegion[];
  onSaveDesign: () => void;
  onDesignChange?: (color: string, pattern: string, patternColor: string) => void;
}

// --- Data Constants ---
const POLISH_COLORS = [
  { name: 'Classic Red', color: '#DC2626', hex: '#DC2626' },
  { name: 'Pretty Pink', color: '#EC4899', hex: '#EC4899' },
  { name: 'Ocean Blue', color: '#2563EB', hex: '#2563EB' },
  { name: 'Emerald Green', color: '#059669', hex: '#059669' },
  { name: 'Sunset Orange', color: '#EA580C', hex: '#EA580C' },
  { name: 'Royal Purple', color: '#7C3AED', hex: '#7C3AED' },
  { name: 'Golden Yellow', color: '#D97706', hex: '#D97706' },
  { name: 'Midnight Black', color: '#1F2937', hex: '#1F2937' },
  { name: 'Rose Gold', color: '#E879F9', hex: '#E879F9' },
  { name: 'Coral', color: '#F97316', hex: '#F97316' },
  { name: 'Mint Green', color: '#10B981', hex: '#10B981' },
  { name: 'Lavender', color: '#A855F7', hex: '#A855F7' },
  { name: 'Cherry Red', color: '#EF4444', hex: '#EF4444' },
  { name: 'Aqua Blue', color: '#06B6D4', hex: '#06B6D4' },
  { name: 'Peach', color: '#FB7185', hex: '#FB7185' },
  { name: 'Silver', color: '#94A3B8', hex: '#94A3B8' },
  { name: 'Deep Blue', color: '#1E40AF', hex: '#1E40AF' },
  { name: 'Hot Pink', color: '#F472B6', hex: '#F472B6' },
  { name: 'Forest Green', color: '#16A34A', hex: '#16A34A' },
  { name: 'Pure White', color: '#FFFFFF', hex: '#FFFFFF' },
];

const GRADIENT_COLORS = [
  { name: 'Sunset Vibes', colors: ['#FF6B6B', '#FFE66D'], id: 'sunset' },
  { name: 'Ocean Breeze', colors: ['#4ECDC4', '#44A08D'], id: 'ocean' },
  { name: 'Purple Haze', colors: ['#A8EDEA', '#C471ED'], id: 'purple' },
  { name: 'Cotton Candy', colors: ['#FFB6C1', '#FF69B4'], id: 'cotton' },
  { name: 'Tropical', colors: ['#00C9FF', '#92FE9D'], id: 'tropical' },
  { name: 'Rose Gold', colors: ['#F093FB', '#F5576C'], id: 'rosegold' },
  { name: 'Galaxy', colors: ['#667eea', '#764ba2'], id: 'galaxy' },
  { name: 'Peachy', colors: ['#FFECD2', '#FCB69F'], id: 'peachy' },
  { name: 'Aurora', colors: ['#00C9FF', '#92FE9D', '#FFE066'], id: 'aurora' },
  { name: 'Fire', colors: ['#FF416C', '#FF4B2B'], id: 'fire' },
  { name: 'Mermaid', colors: ['#56AB2F', '#A8E6CF'], id: 'mermaid' },
  { name: 'Cosmic', colors: ['#C33764', '#1D2671'], id: 'cosmic' },
];

const DESIGN_PATTERNS = [
  { name: 'Solid', id: 'solid' },
  { name: 'French Tip', id: 'french' },
  { name: 'Polka Dots', id: 'dots' },
  { name: 'Stripes', id: 'stripes' },
  { name: 'Floral', id: 'floral' },
  { name: 'Glitter', id: 'glitter' },
  { name: 'Gradient', id: 'gradient' },
  { name: 'Marble', id: 'marble' },
  { name: 'Ombre', id: 'ombre' },
  { name: 'Checkerboard', id: 'checkerboard' },
  { name: 'Hearts', id: 'hearts' },
  { name: 'Stars', id: 'stars' },
  { name: 'Geometric', id: 'geometric' },
  { name: 'Animal Print', id: 'animal' },
  { name: 'Lace', id: 'lace' },
  { name: 'Swirls', id: 'swirls' },
  { name: 'Zigzag', id: 'zigzag' },
  { name: 'Tribal', id: 'tribal' },
];

const PATTERN_COLORS = [
  { name: 'White', color: '#FFFFFF' },
  { name: 'Black', color: '#000000' },
  { name: 'Gold', color: '#FFD700' },
  { name: 'Silver', color: '#C0C0C0' },
  { name: 'Pink', color: '#FF69B4' },
  { name: 'Blue', color: '#4169E1' },
  { name: 'Red', color: '#FF0000' },
  { name: 'Green', color: '#00FF00' },
  { name: 'Purple', color: '#8A2BE2' },
  { name: 'Orange', color: '#FFA500' },
];

const createNailPath = (ctx: CanvasRenderingContext2D, nail: NailRegion) => {
  const { x, y, width, height } = nail;

  const topRadius = Math.min(width, height) * 0.5;
  const bottomRadius = topRadius * 0.25;
  const bottomInset = width * 0.1;
  const centerX = x + width / 2;

  ctx.beginPath();
  ctx.moveTo(x + topRadius, y);
  ctx.lineTo(x + width - topRadius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + topRadius);

  ctx.lineTo(x + width - bottomInset, y + height - bottomRadius);
  ctx.quadraticCurveTo(
    centerX,
    y + height + bottomRadius,
    x + bottomInset,
    y + height - bottomRadius
  );

  ctx.lineTo(x, y + topRadius);
  ctx.quadraticCurveTo(x, y, x + topRadius, y);
  ctx.closePath();
};

const VirtualNailArt: React.FC<VirtualNailArtProps> = ({ canvasRef, detectedNails, onSaveDesign, onDesignChange }) => {
  const [selectedColor, setSelectedColor] = useState(POLISH_COLORS[0]);
  const [selectedGradient, setSelectedGradient] = useState<typeof GRADIENT_COLORS[0] | null>(null);
  const [selectedPattern, setSelectedPattern] = useState(DESIGN_PATTERNS[0]);
  const [selectedPatternColor, setSelectedPatternColor] = useState(PATTERN_COLORS[0]);
  const [isApplying, setIsApplying] = useState(false);
  const [colorMode, setColorMode] = useState<'solid' | 'gradient'>('solid');

  useEffect(() => {
    const currentColor = colorMode === 'gradient' && selectedGradient
      ? selectedGradient.colors[0]
      : selectedColor.color;
    const currentPatternColor = selectedPatternColor.color;

    onDesignChange?.(currentColor, selectedPattern.name, currentPatternColor);
  }, [selectedColor, selectedGradient, selectedPattern, selectedPatternColor, colorMode, onDesignChange]);

  const applyVirtualPolish = () => {
    if (!canvasRef.current || detectedNails.length === 0) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    setIsApplying(true);

    detectedNails.forEach((nail) => {
      applyDesignToNail(ctx, nail, selectedColor, selectedPattern, selectedGradient, selectedPatternColor);
    });

    setTimeout(() => setIsApplying(false), 1000);
  };

  const applyDesignToNail = (
    ctx: CanvasRenderingContext2D,
    nail: NailRegion,
    color: typeof POLISH_COLORS[0],
    pattern: typeof DESIGN_PATTERNS[0],
    gradient?: typeof GRADIENT_COLORS[0] | null,
    patternColor?: typeof PATTERN_COLORS[0]
  ) => {
    const { x, y, width, height } = nail;

    ctx.save();
    createNailPath(ctx, nail);
    ctx.clip();

    // Helper function to apply base color/gradient
    const applyBaseColor = () => {
      if (gradient && colorMode === 'gradient') {
        const canvasGradient = ctx.createLinearGradient(x, y, x, y + height);
        gradient.colors.forEach((gradColor, index) => {
          canvasGradient.addColorStop(index / (gradient.colors.length - 1), gradColor);
        });
        ctx.fillStyle = canvasGradient;
      } else {
        ctx.fillStyle = color.color;
      }
      ctx.fill();
    };

    switch (pattern.id) {
      case 'solid':
        applyBaseColor();
        break;

      case 'french':
        // Base with selected color
        applyBaseColor();
        // White tip
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(x, y, width, height * 0.3);
        break;

      case 'dots':
        applyBaseColor();
        ctx.fillStyle = patternColor?.color || '#FFFFFF';
        for (let i = 0; i < 5; i++) {
          for (let j = 0; j < 3; j++) {
            ctx.beginPath();
            ctx.arc(
              x + (width / 3) * (i + 1),
              y + (height / 5) * (j + 1),
              2,
              0,
              2 * Math.PI
            );
            ctx.fill();
          }
        }
        break;

      case 'stripes':
        applyBaseColor();
        ctx.fillStyle = patternColor?.color || '#FFFFFF';
        for (let i = 0; i < 5; i++) {
          ctx.fillRect(x + (width / 6) * i, y, 2, height);
        }
        break;

      case 'floral':
        applyBaseColor();
        ctx.fillStyle = patternColor?.color || '#FFFFFF';
        // Simple flower pattern
        for (let i = 0; i < 2; i++) {
          for (let j = 0; j < 2; j++) {
            // Flower center
            ctx.beginPath();
            ctx.arc(
              x + (width / 3) * (i + 1),
              y + (height / 3) * (j + 1),
              3,
              0,
              2 * Math.PI
            );
            ctx.fill();
            
            // Petals
            for (let p = 0; p < 5; p++) {
              const angle = (p * 72) * (Math.PI / 180);
              ctx.beginPath();
              ctx.arc(
                x + (width / 3) * (i + 1) + Math.cos(angle) * 6,
                y + (height / 3) * (j + 1) + Math.sin(angle) * 6,
                2,
                0,
                2 * Math.PI
              );
              ctx.fill();
            }
          }
        }
        break;

      case 'glitter':
        applyBaseColor();
        // Glitter effect
        ctx.fillStyle = patternColor?.color || '#FFD700';
        for (let i = 0; i < 30; i++) {
          const glitterX = x + Math.random() * width;
          const glitterY = y + Math.random() * height;
          const size = Math.random() * 2 + 0.5;
          ctx.fillRect(glitterX, glitterY, size, size);
        }
        break;

      case 'gradient':
        if (gradient && colorMode === 'gradient') {
          const canvasGradient = ctx.createLinearGradient(x, y, x, y + height);
          gradient.colors.forEach((gradColor, index) => {
            canvasGradient.addColorStop(index / (gradient.colors.length - 1), gradColor);
          });
          ctx.fillStyle = canvasGradient;
        } else {
          const canvasGradient = ctx.createLinearGradient(x, y, x, y + height);
          canvasGradient.addColorStop(0, color.color);
          canvasGradient.addColorStop(1, '#FFFFFF');
          ctx.fillStyle = canvasGradient;
        }
        ctx.fill();
        break;

      case 'marble':
        applyBaseColor();
        ctx.strokeStyle = patternColor?.color || '#FFFFFF';
        ctx.lineWidth = 1;
        for (let i = 0; i < 10; i++) {
          ctx.beginPath();
          ctx.moveTo(x + Math.random() * width, y + Math.random() * height);
          ctx.bezierCurveTo(
            x + Math.random() * width, y + Math.random() * height,
            x + Math.random() * width, y + Math.random() * height,
            x + Math.random() * width, y + Math.random() * height
          );
          ctx.stroke();
        }
        break;

      case 'ombre': {
        const ombreGradient = ctx.createLinearGradient(x, y, x + width, y + height);
        ombreGradient.addColorStop(0, color.color);
        ombreGradient.addColorStop(0.5, color.color + '80');
        ombreGradient.addColorStop(1, '#FFFFFF');
        ctx.fillStyle = ombreGradient;
        ctx.fill();
        break;
      }

      case 'checkerboard': {
        applyBaseColor();
        ctx.fillStyle = patternColor?.color || '#FFFFFF';
        const checkSize = Math.min(width, height) / 4;
        for (let row = 0; row < 4; row++) {
          for (let col = 0; col < 4; col++) {
            if ((row + col) % 2 === 0) {
              ctx.fillRect(
                x + col * checkSize,
                y + row * checkSize,
                checkSize,
                checkSize
              );
            }
          }
        }
        break;
      }
      case 'hearts':
        applyBaseColor();
        ctx.fillStyle = patternColor?.color || '#FF69B4';
        // Draw multiple hearts
        for (let i = 0; i < 2; i++) {
          for (let j = 0; j < 2; j++) {
            const heartX = x + (width / 3) * (i + 1);
            const heartY = y + (height / 3) * (j + 1);
            const size = 4;
            
            ctx.beginPath();
            ctx.arc(heartX - size/2, heartY - size/2, size/2, 0, Math.PI, true);
            ctx.arc(heartX + size/2, heartY - size/2, size/2, 0, Math.PI, true);
            ctx.lineTo(heartX, heartY + size);
            ctx.fill();
          }
        }
        break;

      case 'stars':
        applyBaseColor();
        ctx.fillStyle = patternColor?.color || '#FFD700';
        // Draw multiple stars
        for (let i = 0; i < 2; i++) {
          for (let j = 0; j < 2; j++) {
            const starX = x + (width / 3) * (i + 1);
            const starY = y + (height / 3) * (j + 1);
            const size = 4;
            
            ctx.beginPath();
            for (let k = 0; k < 5; k++) {
              const angle = (k * 144 - 90) * Math.PI / 180;
              const radius = k % 2 === 0 ? size : size / 2;
              const px = starX + Math.cos(angle) * radius;
              const py = starY + Math.sin(angle) * radius;
              if (k === 0) ctx.moveTo(px, py);
              else ctx.lineTo(px, py);
            }
            ctx.closePath();
            ctx.fill();
          }
        }
        break;

      case 'geometric':
        applyBaseColor();
        ctx.strokeStyle = patternColor?.color || '#FFFFFF';
        ctx.lineWidth = 2;
        // Triangle pattern
        for (let i = 0; i < 2; i++) {
          for (let j = 0; j < 2; j++) {
            const centerX = x + (width / 3) * (i + 1);
            const centerY = y + (height / 3) * (j + 1);
            const size = 8;
            
            ctx.beginPath();
            ctx.moveTo(centerX, centerY - size);
            ctx.lineTo(centerX - size, centerY + size);
            ctx.lineTo(centerX + size, centerY + size);
            ctx.closePath();
            ctx.stroke();
          }
        }
        break;

      case 'animal':
        applyBaseColor();
        ctx.fillStyle = patternColor?.color || '#000000';
        // Leopard spots
        for (let i = 0; i < 10; i++) {
          ctx.beginPath();
          ctx.arc(
            x + Math.random() * width,
            y + Math.random() * height,
            Math.random() * 3 + 1,
            0,
            2 * Math.PI
          );
          ctx.fill();
        }
        break;

      case 'lace':
        applyBaseColor();
        ctx.strokeStyle = patternColor?.color || '#FFFFFF';
        ctx.lineWidth = 1;
        // Delicate lace pattern
        for (let i = 0; i < 5; i++) {
          for (let j = 0; j < 3; j++) {
            ctx.beginPath();
            ctx.arc(
              x + (width / 6) * (i + 1),
              y + (height / 4) * (j + 1),
              2,
              0,
              2 * Math.PI
            );
            ctx.stroke();
          }
        }
        break;

      case 'swirls':
        applyBaseColor();
        ctx.strokeStyle = patternColor?.color || '#FFFFFF';
        ctx.lineWidth = 1.5;
        // Swirl pattern
        for (let i = 0; i < 2; i++) {
          for (let j = 0; j < 2; j++) {
            const centerX = x + (width / 3) * (i + 1);
            const centerY = y + (height / 3) * (j + 1);
            const radius = 6;
            
            ctx.beginPath();
            ctx.arc(centerX, centerY, radius, 0, Math.PI * 1.5);
            ctx.stroke();
          }
        }
        break;

      case 'zigzag':
        applyBaseColor();
        ctx.strokeStyle = patternColor?.color || '#FFFFFF';
        ctx.lineWidth = 2;
        // Zigzag pattern
        ctx.beginPath();
        ctx.moveTo(x, y + height / 2);
        for (let i = 0; i < 5; i++) {
          const zigX = x + (width / 5) * i;
          const zigY = i % 2 === 0 ? y + height / 3 : y + 2 * height / 3;
          ctx.lineTo(zigX, zigY);
        }
        ctx.stroke();
        break;

      case 'tribal':
        applyBaseColor();
        ctx.fillStyle = patternColor?.color || '#000000';
        // Tribal pattern lines
        ctx.fillRect(x + width / 4, y + 5, 3, height - 10);
        ctx.fillRect(x + 3 * width / 4, y + 5, 3, height - 10);
        // Tribal pattern dots
        for (let i = 0; i < 3; i++) {
          ctx.beginPath();
          ctx.arc(
            x + width / 2,
            y + (height / 4) * (i + 1),
            2,
            0,
            2 * Math.PI
          );
          ctx.fill();
        }
        break;

      default:
        applyBaseColor();
        break;
    }

    ctx.restore();
  };

  return (
    <div className="space-y-4">
      {/* Color Mode Selector */}
      <Card className="bg-white/10 backdrop-blur-lg border-white/20">
        <CardContent className="pt-6">
          <div className="flex gap-2">
            <Button
              onClick={() => setColorMode('solid')}
              variant={colorMode === 'solid' ? 'default' : 'outline'}
              size="sm"
              className="flex-1"
            >
              Solid Colors
            </Button>
            <Button
              onClick={() => setColorMode('gradient')}
              variant={colorMode === 'gradient' ? 'default' : 'outline'}
              size="sm"
              className="flex-1"
            >
              Gradient Colors
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Color Palette */}
      {colorMode === 'solid' ? (
        <Card className="bg-white/10 backdrop-blur-lg border-white/20">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Palette className="w-5 h-5" />
              Polish Colors
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-5 gap-2">
              {POLISH_COLORS.map((color) => (
                <button
                  key={color.name}
                  onClick={() => setSelectedColor(color)}
                  className={`w-12 h-12 rounded-full border-2 transition-all ${
                    selectedColor.name === color.name
                      ? 'border-white scale-110'
                      : 'border-gray-400 hover:scale-105'
                  }`}
                  style={{ backgroundColor: color.color }}
                  title={color.name}
                />
              ))}
            </div>
            <div className="mt-2 text-center">
              <Badge variant="outline" className="text-white">
                {selectedColor.name}
              </Badge>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card className="bg-white/10 backdrop-blur-lg border-white/20">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5" />
              Gradient Colors
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-2">
              {GRADIENT_COLORS.map((gradientOption) => (
                <button
                  key={gradientOption.id}
                  onClick={() => setSelectedGradient(gradientOption)}
                  className={`w-full h-12 rounded-lg border-2 transition-all flex items-center justify-center ${
                    selectedGradient?.id === gradientOption.id
                      ? 'border-white scale-105'
                      : 'border-gray-400 hover:scale-105'
                  }`}
                  style={{
                    background: `linear-gradient(45deg, ${gradientOption.colors.join(', ')})`
                  }}
                  title={gradientOption.name}
                >
                  <span className="text-white text-xs font-semibold bg-black/30 px-2 py-1 rounded">
                    {gradientOption.name}
                  </span>
                </button>
              ))}
            </div>
            <div className="mt-2 text-center">
              <Badge variant="outline" className="text-white">
                {selectedGradient ? selectedGradient.name : 'Select Gradient'}
              </Badge>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Design Patterns */}
      <Card className="bg-white/10 backdrop-blur-lg border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5" />
            Design Patterns
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-2">
            {DESIGN_PATTERNS.map((pattern) => (
              <Button
                key={pattern.id}
                onClick={() => setSelectedPattern(pattern)}
                variant={selectedPattern.id === pattern.id ? 'default' : 'outline'}
                size="sm"
                className="text-xs"
              >
                {pattern.name}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Pattern Colors */}
      {selectedPattern.id !== 'solid' && selectedPattern.id !== 'french' && selectedPattern.id !== 'gradient' && selectedPattern.id !== 'ombre' && (
        <Card className="bg-white/10 backdrop-blur-lg border-white/20">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2 text-sm">
              <Palette className="w-4 h-4" />
              Pattern Colors
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-5 gap-2">
              {PATTERN_COLORS.map((patternColor) => (
                <button
                  key={patternColor.name}
                  onClick={() => setSelectedPatternColor(patternColor)}
                  className={`w-8 h-8 rounded-full border-2 transition-all ${
                    selectedPatternColor.name === patternColor.name
                      ? 'border-white scale-110'
                      : 'border-gray-400 hover:scale-105'
                  }`}
                  style={{ backgroundColor: patternColor.color }}
                  title={patternColor.name}
                />
              ))}
            </div>
            <div className="mt-2 text-center">
              <Badge variant="outline" className="text-white text-xs">
                {selectedPatternColor.name} for {selectedPattern.name}
              </Badge>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Action Buttons */}
      <Card className="bg-white/10 backdrop-blur-lg border-white/20">
        <CardContent className="pt-6 space-y-3">
          <Button
            onClick={applyVirtualPolish}
            className="w-full"
            disabled={isApplying || detectedNails.length === 0}
          >
            <Palette className="w-4 h-4 mr-2" />
            {isApplying ? 'Applying...' : 'Apply Virtual Polish'}
          </Button>
          <Button
            onClick={onSaveDesign}
            variant="outline"
            className="w-full"
            disabled={detectedNails.length === 0}
          >
            <Save className="w-4 h-4 mr-2" />
            Save Design
          </Button>
        </CardContent>
      </Card>

      {/* Live Preview Info */}
      <Card className="bg-white/10 backdrop-blur-lg border-white/20">
        <CardHeader>
          <CardTitle className="text-white text-sm">Live Preview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-sm text-gray-300 space-y-1">
            <p>Selected: {colorMode === 'gradient' && selectedGradient ? selectedGradient.name : selectedColor.name}</p>
            <p>Pattern: {selectedPattern.name}</p>
            {selectedPattern.id !== 'solid' && selectedPattern.id !== 'french' && selectedPattern.id !== 'gradient' && selectedPattern.id !== 'ombre' && (
              <p>Pattern Color: {selectedPatternColor.name}</p>
            )}
            <p>Nails detected: {detectedNails.length}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default VirtualNailArt;