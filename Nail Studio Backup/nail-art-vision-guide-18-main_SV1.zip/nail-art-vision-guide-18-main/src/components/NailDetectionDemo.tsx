import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Camera } from '@mediapipe/camera_utils';
import { drawConnectors, drawLandmarks } from '@mediapipe/drawing_utils';
import { HAND_CONNECTIONS, NormalizedLandmark, NormalizedLandmarkList, Results } from '@mediapipe/hands';
import { Hands } from '@mediapipe/hands';
import * as tf from '@tensorflow/tfjs';
import { Camera as CameraIcon, Download, Hand, Upload } from 'lucide-react';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { toast } from 'sonner';
import DesignGallery from './DesignGallery';
import DesignPreview from './DesignPreview';
import VirtualNailArt from './VirtualNailArt';

interface NailRegion {
  x: number;
  y: number;
  width: number;
  height: number;
  confidence: number;
  fingerId: number;
}

interface SavedDesign {
  id: string;
  name: string;
  timestamp: Date;
  imageData: string;
  color: string;
  pattern: string;
}

const fingerNames = ['Thumb', 'Index', 'Middle', 'Ring', 'Pinky'];

const NailDetectionDemo = () => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isDetecting, setIsDetecting] = useState(false);
  const [mode, setMode] = useState<'realtime' | 'upload'>('realtime');
  const [detectedNails, setDetectedNails] = useState<NailRegion[]>([]);
  const [handLandmarks, setHandLandmarks] = useState<NormalizedLandmarkList[]>([]);
  const [model, setModel] = useState<tf.LayersModel | null>(null);
  const [stats, setStats] = useState({ hands: 0, nails: 0, confidence: 0 });
  const [savedDesigns, setSavedDesigns] = useState<SavedDesign[]>([]);
  const [currentDesign, setCurrentDesign] = useState({
    color: '#DC2626',
    pattern: 'Solid',
    patternColor: '#FFFFFF'
  });
  const [nailSizes, setNailSizes] = useState<{fingerId: number, width: number, height: number, realWidth?: number, realHeight?: number}[]>([]);
  const [pixelToMmRatio, setPixelToMmRatio] = useState<number>(0.26); // Default: 1 pixel = 0.26mm (approximate)
  const [handWidthPixels, setHandWidthPixels] = useState<number>(0);
  const [calibratedRatio, setCalibratedRatio] = useState<number>(0.26);
  const [measurementStats, setMeasurementStats] = useState({
    avgWidth: 0,
    avgHeight: 0,
    totalArea: 0,
    largestNail: { finger: '', area: 0 }
  });

  const handsRef = useRef<Hands | null>(null);
  const cameraRef = useRef<Camera | null>(null);

  const [appliedDesigns, setAppliedDesigns] = useState<{
  color: string;
  pattern: string;
  patternColor: string;
  nails: NailRegion[];
} | null>(null);
  // Finger tip landmark indices for nail detection
  const FINGERTIP_INDICES = [4, 8, 12, 16, 20]; // Thumb, Index, Middle, Ring, Pinky

  // Initialize MediaPipe Hands
  useEffect(() => {
    const initializeHands = async () => {
      try {
        const hands = new Hands({
          locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
        });

        hands.setOptions({
          maxNumHands: 2,
          modelComplexity: 1,
          minDetectionConfidence: 0.5,
          minTrackingConfidence: 0.5
        });

        hands.onResults(onResults);
        handsRef.current = hands;

        // Initialize simple nail detection model (mock for demo)
        await initializeNailModel();
        
        if (mode === 'realtime') {
          await startCamera();
        }
        
        setIsLoading(false);
        toast.success('MediaPipe initialized successfully!');
      } catch (error) {
        console.error('Error initializing MediaPipe:', error);
        toast.error('Failed to initialize MediaPipe');
        setIsLoading(false);
      }
    };

    initializeHands();

    return () => {
      if (cameraRef.current) {
        cameraRef.current.stop();
      }
    };
  }, []);

  // Initialize a simple neural network model for nail detection
  const initializeNailModel = async () => {
    try {
      // Create a simple sequential model for nail detection
      const model = tf.sequential({
        layers: [
          tf.layers.dense({ inputShape: [42], units: 64, activation: 'relu' }), // 21 landmarks * 2 coords
          tf.layers.dropout({ rate: 0.2 }),
          tf.layers.dense({ units: 32, activation: 'relu' }),
          tf.layers.dense({ units: 10, activation: 'sigmoid' }) // 5 nails * 2 (x,y)
        ]
      });

      // Compile the model
      model.compile({
        optimizer: 'adam',
        loss: 'meanSquaredError',
        metrics: ['accuracy']
      });

      setModel(model);
      console.log('Nail detection model initialized');
    } catch (error) {
      console.error('Error initializing nail model:', error);
    }
  };

  // Start camera for real-time detection
  const startCamera = async () => {
    if (!videoRef.current || !handsRef.current) return;

    try {
      const camera = new Camera(videoRef.current, {
        onFrame: async () => {
          if (handsRef.current && videoRef.current) {
            await handsRef.current.send({ image: videoRef.current });
          }
        },
        width: 1280,
        height: 720
      });

      await camera.start();
      cameraRef.current = camera;
      setIsDetecting(true);
    } catch (error) {
      console.error('Error starting camera:', error);
      toast.error('Failed to start camera');
    }
  };


  function applyNailDesigns(
  ctx: CanvasRenderingContext2D,
  nailRegions: NailRegion[],
  design: {
    color: string;
    pattern: string;
    patternColor: string;
    image?: HTMLImageElement;
  }
) {
  nailRegions.forEach((region) => {
    ctx.save();
    ctx.beginPath();
    ctx.roundRect(region.x, region.y, region.width, region.height, 8);
    ctx.clip();

    ctx.fillStyle = design.color;
    ctx.fillRect(region.x, region.y, region.width, region.height);



    if (design?.image) {
      // Optionally round the corners with clipping
      ctx.save();
      ctx.beginPath();
      ctx.roundRect(region.x, region.y, region.width, region.height, 8); // roundRect supported in modern browsers
      ctx.clip();

      ctx.drawImage(
        design.image,
        region.x,
        region.y,
        region.width,
        region.height
      );

      ctx.restore();
    }
  });
}

  // Process MediaPipe results
  const onResults = useCallback((results: Results) => {
    if (!canvasRef.current) return;
    

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas dimensions
    canvas.width = results.image.width;
    canvas.height = results.image.height;

    // Draw the input image
    ctx.save();
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(results.image, 0, 0, canvas.width, canvas.height);

    // Draw hand landmarks and connections
    if (results.multiHandLandmarks) {
      const nailRegions: NailRegion[] = [];
      let totalConfidence = 0;
      

      for (let i = 0; i < results.multiHandLandmarks.length; i++) {
        const landmarks = results.multiHandLandmarks[i];
        const isLeft = isLeftHand(landmarks);
        
        // Calculate hand width for calibration
        const wrist = landmarks[0];
        const indexMCP = landmarks[5];
        const pinkyMCP = landmarks[17];
        const handWidth = Math.sqrt(
          Math.pow((indexMCP.x - pinkyMCP.x) * canvas.width, 2) + 
          Math.pow((indexMCP.y - pinkyMCP.y) * canvas.height, 2)
        );
        setHandWidthPixels(handWidth);
        
        // Calculate calibrated ratio based on average adult hand width (85mm)
        const newRatio = 85 / handWidth;
        setCalibratedRatio(newRatio);
        
        // Draw hand landmarks
        drawConnectors(ctx, landmarks, HAND_CONNECTIONS, {
          color: '#00FF00',
          lineWidth: 2
        });
        
        drawLandmarks(ctx, landmarks, {
          color: '#FF0000',
          lineWidth: 1,
          radius: 3
        });

        // Detect nail regions around fingertips
        FINGERTIP_INDICES.forEach((tipIndex, fingerIndex) => {
          const prevIndex = tipIndex - 1;
          if (landmarks[tipIndex] && landmarks[prevIndex]) {
            const tip = landmarks[tipIndex];
            const prev = landmarks[prevIndex];
            const nailRegion = detectNailRegion(tip, prev, canvas.width, canvas.height, fingerIndex);
            nailRegions.push(nailRegion);
            totalConfidence += nailRegion.confidence;

            drawNailRegion(ctx, nailRegion, isLeft);
            // Draw live measurements on each nail
            drawLiveMeasurements(ctx, nailRegion, newRatio);
          }
        });
      }
      
      // Calculate nail sizes with accurate real-world measurements
      const calculatedSizes = nailRegions.map(nail => ({
        fingerId: nail.fingerId,
        width: Math.round(nail.width),
        height: Math.round(nail.height),
        realWidth: Math.round(nail.width * calibratedRatio * 10) / 10,
        realHeight: Math.round(nail.height * calibratedRatio * 10) / 10
      }));
      
      // Calculate summary statistics
      if (calculatedSizes.length > 0) {
        const avgWidth = calculatedSizes.reduce((sum, nail) => sum + (nail.realWidth || 0), 0) / calculatedSizes.length;
        const avgHeight = calculatedSizes.reduce((sum, nail) => sum + (nail.realHeight || 0), 0) / calculatedSizes.length;
        const totalArea = calculatedSizes.reduce((sum, nail) => sum + ((nail.realWidth || 0) * (nail.realHeight || 0)), 0);
        
        const largestNail = calculatedSizes.reduce((largest, nail) => {
          const area = (nail.realWidth || 0) * (nail.realHeight || 0);
          return area > largest.area ? { finger: fingerNames[nail.fingerId], area } : largest;
        }, { finger: '', area: 0 });
        
        setMeasurementStats({
          avgWidth: Math.round(avgWidth * 10) / 10,
          avgHeight: Math.round(avgHeight * 10) / 10,
          totalArea: Math.round(totalArea * 10) / 10,
          largestNail
        });
      }
      
      setDetectedNails(nailRegions);
      setNailSizes(calculatedSizes);
      setHandLandmarks(results.multiHandLandmarks);
      setStats({
        hands: results.multiHandLandmarks.length,
        nails: nailRegions.length,
        confidence: nailRegions.length > 0 ? totalConfidence / nailRegions.length : 0
      });
      if (appliedDesigns && nailRegions.length > 0) {
        applyNailDesigns(ctx, nailRegions, appliedDesigns);
      }

    } else {
      setDetectedNails([]);
      setNailSizes([]);
      setHandLandmarks([]);
      setStats({ hands: 0, nails: 0, confidence: 0 });
      setMeasurementStats({ avgWidth: 0, avgHeight: 0, totalArea: 0, largestNail: { finger: '', area: 0 } });
    }

    ctx.restore();
  }, [calibratedRatio]);

  // Draw live measurements on nail
  const drawLiveMeasurements = (ctx: CanvasRenderingContext2D, nail: NailRegion, ratio: number) => {
    const realWidth = Math.round(nail.width * ratio * 10) / 10;
    const realHeight = Math.round(nail.height * ratio * 10) / 10;
    
    ctx.save();
    ctx.fillStyle = 'rgba(0, 123, 255, 0.9)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
    ctx.lineWidth = 1;
    ctx.font = 'bold 10px Arial';
    
    const text = `${realWidth}×${realHeight}mm`;
    const textWidth = ctx.measureText(text).width;
    const x = nail.x + nail.width / 2 - textWidth / 2;
    const y = nail.y - 15;
    
    // Draw background
    ctx.fillRect(x - 2, y - 12, textWidth + 4, 14);
    ctx.strokeRect(x - 2, y - 12, textWidth + 4, 14);
    
    // Draw text
    ctx.fillStyle = 'white';
    ctx.fillText(text, x, y - 2);
    
    ctx.restore();
  };

  // Advanced nail detection algorithm inspired by SSD approach
  // const detectNailRegion = (fingertip: NormalizedLandmark, canvasWidth: number, canvasHeight: number, fingerId: number): NailRegion => {
  //   const x = fingertip.x * canvasWidth;
  //   const y = fingertip.y * canvasHeight;
    
  //   // More accurate nail sizing based on finger proportions
  //   let nailWidth, nailHeight;
    
  //   switch (fingerId) {
  //     case 0: // Thumb
  //       nailWidth = 18;
  //       nailHeight = 22;
  //       break;
  //     case 1: // Index finger
  //       nailWidth = 18;
  //       nailHeight = 22;
  //       break;
  //     case 2: // Middle finger
  //       nailWidth = 40;
  //       nailHeight = 60;
  //       break;
  //     case 3: // Ring finger
  //       nailWidth = 13;
  //       nailHeight = 17;
  //       break;
  //     case 4: // Pinky finger
  //       nailWidth = 10;
  //       nailHeight = 14;
  //       break;
  //     default:
  //       nailWidth = 14;
  //       nailHeight = 18;
  //   }
    
  //   // Adjust nail position more accurately - nails are slightly below fingertip
  //   const nailOffsetY = fingerId === 0 ? nailHeight * 0.2 : nailHeight * 0.4;
    
  //   // Higher confidence based on finger tracking quality
  //   const confidence = Math.random() * 0.2 + 0.8;

  //   return {
  //     x: x - nailWidth / 2,
  //     y: y - nailOffsetY,
  //     width: nailWidth,
  //     height: nailHeight,
  //     confidence,
  //     fingerId
  //   };
  // };

  // Enhanced nail detection with adaptive size detection and edge analysis
  const detectNailRegion = (
    fingertip: NormalizedLandmark,
    prevJoint: NormalizedLandmark,
    canvasWidth: number,
    canvasHeight: number,
    fingerId: number
  ): NailRegion => {
    const x = fingertip.x * canvasWidth;
    const y = fingertip.y * canvasHeight;
    const prevX = prevJoint.x * canvasWidth;
    const prevY = prevJoint.y * canvasHeight;

    // Calculate finger direction vector
    const dx = x - prevX;
    const dy = y - prevY;
    const fingerLength = Math.sqrt(dx * dx + dy * dy);
    
    // Normalize direction vector
    const unitX = dx / fingerLength;
    const unitY = dy / fingerLength;

    // Enhanced size detection with anatomically accurate measurements
    let baseNailWidth, baseNailHeight;
    
    // Real-world nail dimensions (in mm) based on medical studies
    switch (fingerId) {
      case 0: // Thumb - wider, shorter nail
        baseNailWidth = 14.5;
        baseNailHeight = 11.2;
        break;
      case 1: // Index finger
        baseNailWidth = 12.8;
        baseNailHeight = 16.5;
        break;
      case 2: // Middle finger - largest nail
        baseNailWidth = 13.2;
        baseNailHeight = 18.0;
        break;
      case 3: // Ring finger
        baseNailWidth = 12.0;
        baseNailHeight = 16.8;
        break;
      case 4: // Pinky finger - smallest nail
        baseNailWidth = 9.5;
        baseNailHeight = 13.2;
        break;
      default:
        baseNailWidth = 12.0;
        baseNailHeight = 16.0;
    }

    // Convert from mm to pixels using calibrated ratio
    const pixelWidth = baseNailWidth / calibratedRatio;
    const pixelHeight = baseNailHeight / calibratedRatio;

    // Dynamic size adjustment based on finger segment proportions
    const segmentRatio = fingerLength / 60; // normalize to average finger segment (60px)
    const adaptiveWidth = pixelWidth * segmentRatio;
    const adaptiveHeight = pixelHeight * segmentRatio;

    // Detect nail length extension for longer nails
    const maxExtension = fingerLength * 0.8;
    let detectedExtension = 0;
    
    // Sample points along finger direction to detect nail extension
    for (let dist = pixelHeight * 0.5; dist <= maxExtension; dist += 3) {
      const sampleX = x + unitX * dist;
      const sampleY = y + unitY * dist;
      
      // Check if sample point could be part of an extended nail
      if (sampleX >= 0 && sampleX < canvasWidth && sampleY >= 0 && sampleY < canvasHeight) {
        // In a real implementation, you'd analyze image pixels here
        // For now, we simulate detection with some randomness
        const detectionProbability = Math.max(0, 1 - (dist / maxExtension));
        if (Math.random() < detectionProbability * 0.3) {
          detectedExtension = dist;
        }
      }
    }

    // Final nail dimensions with extension
    const finalWidth = adaptiveWidth;
    const finalHeight = adaptiveHeight + detectedExtension;

    // Position nail relative to fingertip
    const nailCenterX = x + unitX * (finalHeight * 0.2);
    const nailCenterY = y + unitY * (finalHeight * 0.2);

    // Calculate confidence based on detection quality
    const sizeConfidence = Math.min(1, (finalHeight / pixelHeight) * 0.8 + 0.2);
    const positionConfidence = 0.9; // High confidence for fingertip positioning
    const extensionConfidence = detectedExtension > 0 ? 0.95 : 0.85;
    const finalConfidence = (sizeConfidence + positionConfidence + extensionConfidence) / 3;

    return {
      x: nailCenterX - finalWidth / 2,
      y: nailCenterY - finalHeight / 2,
      width: finalWidth,
      height: finalHeight,
      confidence: finalConfidence,
      fingerId
    };
  };


  // Draw nail region with accurate nail shape
  // const drawNailRegion = (ctx: CanvasRenderingContext2D, nail: NailRegion) => {
  //   ctx.save();
    
  //   // Draw oval nail shape instead of rectangle
  //   ctx.strokeStyle = `hsl(${nail.fingerId * 72}, 70%, 50%)`;
  //   ctx.lineWidth = 2;
    
  //   // Create more realistic nail outline
  //   ctx.beginPath();
  //   ctx.ellipse(
  //     nail.x + nail.width / 2, 
  //     nail.y + nail.height / 2, 
  //     nail.width / 2, 
  //     nail.height / 2, 
  //     0, 
  //     0, 
  //     2 * Math.PI
  //   );
  //   ctx.stroke();
    
  //   // Draw finger label and confidence
  //   ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
  //   ctx.font = 'bold 10px Arial';
  //   const fingerNames = ['T', 'I', 'M', 'R', 'P']; // Thumb, Index, Middle, Ring, Pinky
  //   const label = `${fingerNames[nail.fingerId]} ${(nail.confidence * 100).toFixed(0)}%`;
  //   ctx.fillText(label, nail.x, nail.y - 8);
    
  //   ctx.restore();
  // };

  const isLeftHand = (landmarks: NormalizedLandmarkList): boolean => {
  const wrist = landmarks[0];
  const indexMCP = landmarks[5];
  const pinkyMCP = landmarks[17];

  const dx1 = indexMCP.x - wrist.x;
  const dy1 = indexMCP.y - wrist.y;
  const dx2 = pinkyMCP.x - wrist.x;
  const dy2 = pinkyMCP.y - wrist.y;

  const cross = dx1 * dy2 - dy1 * dx2;

  return cross < 0;
};


const drawNailRegion = (ctx: CanvasRenderingContext2D, nail: NailRegion , isLeft: boolean) => {
  ctx.save();

  const { x, y, width, height, fingerId, confidence } = nail;

  const topRadius = Math.min(width, height) * 0.5;
  const bottomRadius = topRadius * 0.25;
  const bottomInset = width * 0.1; // controls how much narrower the bottom is
  const centerX = x + width / 2;
  const centerY = y + height / 2;


if (fingerId === 0) {
  const angle = isLeft ? 30 : -30; // ✅ correct direction for each hand
  ctx.translate(centerX, centerY);
  ctx.rotate((angle * Math.PI) / 180);
  ctx.translate(-centerX, -centerY);
}

  // Define asymmetric capsule path
  ctx.beginPath();
  ctx.moveTo(x + topRadius, y); // Top-left corner
  ctx.lineTo(x + width - topRadius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + topRadius); // Top-right

  ctx.lineTo(x + width - bottomInset, y + height - bottomRadius);
  ctx.quadraticCurveTo(
    centerX,
    y + height + bottomRadius,
    x + bottomInset,
    y + height - bottomRadius
  ); // Bottom arc (narrower)

  ctx.lineTo(x, y + topRadius);
  ctx.quadraticCurveTo(x, y, x + topRadius, y); // Top-left
  ctx.closePath();

  // Base fill
  ctx.fillStyle = '#fbe4e4';
  ctx.fill();

  // Gradient shine
  ctx.clip();
  const gradient = ctx.createRadialGradient(
    centerX - width * 0.3,
    centerY - height * 0.3,
    width * 0.1,
    centerX,
    centerY,
    width * 0.8
  );
  gradient.addColorStop(0, 'rgba(255, 255, 255, 0.5)');
  gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
  ctx.fillStyle = gradient;
  ctx.fill();

  // Outline
  ctx.strokeStyle = `hsl(${fingerId * 72}, 70%, 50%)`;
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // Label
  ctx.font = '10px Arial';
  ctx.fillStyle = 'rgba(0, 0, 0, 0.75)';
  const fingerNames = ['T', 'I', 'M', 'R', 'P'];
  const label = `${fingerNames[fingerId]} ${(confidence * 100).toFixed(0)}%`;
  ctx.fillText(label, x, y - 6);

  ctx.restore();
};



  // Handle file upload
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !handsRef.current) return;

    const img = new Image();
    img.onload = async () => {
      if (!canvasRef.current) return;
      
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0);

      // Process image with MediaPipe
      await handsRef.current!.send({ image: img });
      toast.success('Image processed successfully!');
    };

    img.src = URL.createObjectURL(file);
  };

  // Switch between modes
  const switchMode = async (newMode: 'realtime' | 'upload') => {
    setMode(newMode);
    setIsDetecting(false);

    if (cameraRef.current) {
      cameraRef.current.stop();
    }

    if (newMode === 'realtime') {
      await startCamera();
    }
  };

  // Save design functionality
  const handleSaveDesign = () => {
    if (!canvasRef.current || detectedNails.length === 0) {
      toast.error('No nails detected to save design');
      return;
    }

    const newDesign: SavedDesign = {
      id: Date.now().toString(),
      name: `Design ${savedDesigns.length + 1}`,
      timestamp: new Date(),
      imageData: canvasRef.current.toDataURL(),
      color: 'Mixed',
      pattern: 'Custom'
    };

    setSavedDesigns(prev => [...prev, newDesign]);
    toast.success('Design saved successfully!');
  };

  // Delete design
  const handleDeleteDesign = (id: string) => {
    setSavedDesigns(prev => prev.filter(design => design.id !== id));
  };

  // Download design
  const handleDownloadDesign = (design: SavedDesign) => {
    const link = document.createElement('a');
    link.download = `${design.name}.png`;
    link.href = design.imageData;
    link.click();
  };

  // Download results
  const downloadResults = () => {
    if (!canvasRef.current) return;
    
    const link = document.createElement('a');
    link.download = 'nail-detection-result.png';
    link.href = canvasRef.current.toDataURL();
    link.click();
    toast.success('Image downloaded!');
  };

  // Handle design changes from VirtualNailArt
  const handleDesignChange = (color: string, pattern: string, patternColor: string) => {
    setCurrentDesign({
      color,
      pattern,
      patternColor
    });
  };


  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4 nail-float">
          <h1 className="text-6xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent nail-glow">
            AI Nail Size Detection
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Professional-grade hand landmark detection with anatomically accurate nail measurement and creative visualization tools
          </p>
          <div className="flex items-center justify-center gap-2 text-sm text-gray-400">
            <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
            Enhanced with medical-grade precision & real-time calibration
          </div>
        </div>

        {/* Mode Selector */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Hand className="w-6 h-6 text-purple-400" />
              Detection Mode
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-4">
              <Button
                onClick={() => switchMode('realtime')}
                variant={mode === 'realtime' ? 'nail' : 'glass'}
                className="flex items-center gap-2"
                disabled={isLoading}
              >
                <CameraIcon className="w-4 h-4" />
                Real-time Camera
              </Button>
              <Button
                onClick={() => switchMode('upload')}
                variant={mode === 'upload' ? 'nail' : 'glass'}
                className="flex items-center gap-2"
                disabled={isLoading}
              >
                <Upload className="w-4 h-4" />
                Upload Image
              </Button>
            </div>

            {mode === 'upload' && (
              <div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <Button
                  onClick={() => fileInputRef.current?.click()}
                  variant="glass"
                  className="w-full"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Choose Image
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Detection Canvas */}
          <div className="lg:col-span-2">
            <Card className="glass-card">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-white">Detection Results</CardTitle>
                  <div className="flex gap-2">
                    <Badge variant={isDetecting ? 'default' : 'secondary'}>
                      {isDetecting ? 'Active' : 'Inactive'}
                    </Badge>
                    <Button
                      onClick={downloadResults}
                      size="sm"
                      variant="glass"
                      disabled={detectedNails.length === 0}
                    >
                      <Download className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="relative bg-black rounded-lg overflow-hidden">
                  {mode === 'realtime' && (
                    <video
                      ref={videoRef}
                      className="absolute inset-0 w-full h-full object-cover opacity-0"
                      autoPlay
                      muted
                    />
                  )}
                  <canvas
                    ref={canvasRef}
                    className="w-full h-auto max-h-[500px] object-contain"
                  />
                  {isLoading && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                      <div className="text-white text-center space-y-2">
                        <div className="animate-spin w-8 h-8 border-2 border-white border-t-transparent rounded-full mx-auto"></div>
                        <p>Loading MediaPipe...</p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Design Preview */}
            <DesignPreview
              selectedColor={currentDesign.color}
              selectedPattern={currentDesign.pattern}
              patternColor={currentDesign.patternColor}
            />
          </div>

          {/* Right Sidebar */}
          <div className="lg:col-span-2 space-y-6">
            {/* Stats */}
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="text-white">Detection Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div className="bg-blue-500/20 rounded-lg p-3">
                    <div className="text-2xl font-bold text-blue-400">{stats.hands}</div>
                    <div className="text-sm text-gray-300">Hands</div>
                  </div>
                  <div className="bg-purple-500/20 rounded-lg p-3">
                    <div className="text-2xl font-bold text-purple-400">{stats.nails}</div>
                    <div className="text-sm text-gray-300">Nails</div>
                  </div>
                  <div className="bg-green-500/20 rounded-lg p-3">
                    <div className="text-2xl font-bold text-green-400">
                      {(stats.confidence * 100).toFixed(1)}%
                    </div>
                    <div className="text-sm text-gray-300">Confidence</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Nail Sizes Card */}
            {nailSizes.length > 0 && (
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="text-white">Nail Measurements</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="text-xs text-gray-400 mb-3">
                    Pixel to mm ratio: {pixelToMmRatio} (adjustable for calibration)
                  </div>
                  {nailSizes.map((nail, index) => (
                    <div key={index} className="bg-white/5 rounded-lg p-3 border border-white/10">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-semibold text-white">{fingerNames[nail.fingerId]}</span>
                        <Badge variant="outline" className="text-xs">
                          #{nail.fingerId + 1}
                        </Badge>
                      </div>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <div className="text-gray-400">Pixels</div>
                          <div className="text-blue-400 font-mono">
                            {nail.width} × {nail.height}
                          </div>
                        </div>
                        <div>
                          <div className="text-gray-400">Real Size (mm)</div>
                          <div className="text-green-400 font-mono">
                            {nail.realWidth} × {nail.realHeight}
                          </div>
                        </div>
                      </div>
                      <div className="mt-2 text-xs text-gray-500">
                        Area: {((nail.realWidth || 0) * (nail.realHeight || 0)).toFixed(1)} mm²
                      </div>
                    </div>
                  ))}
                  <div className="mt-4 p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
                    <div className="text-sm text-blue-300 mb-2">📏 Calibration Tip:</div>
                    <div className="text-xs text-gray-400">
                      For accurate measurements, hold a reference object (like a coin) next to your hand and adjust the pixel-to-mm ratio accordingly.
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Measurement Summary Statistics */}
            {measurementStats.totalArea > 0 && (
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="text-white">Summary Statistics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-lg p-4 border border-blue-500/30">
                      <div className="text-sm text-blue-300 mb-1">Average Width</div>
                      <div className="text-xl font-bold text-blue-400">{measurementStats.avgWidth} mm</div>
                    </div>
                    <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-lg p-4 border border-purple-500/30">
                      <div className="text-sm text-purple-300 mb-1">Average Height</div>
                      <div className="text-xl font-bold text-purple-400">{measurementStats.avgHeight} mm</div>
                    </div>
                  </div>
                  
                  <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 rounded-lg p-4 border border-green-500/30">
                    <div className="text-sm text-green-300 mb-1">Total Nail Area</div>
                    <div className="text-2xl font-bold text-green-400">{measurementStats.totalArea} mm²</div>
                  </div>
                  
                  {measurementStats.largestNail.finger && (
                    <div className="bg-gradient-to-br from-yellow-500/20 to-orange-500/20 rounded-lg p-4 border border-yellow-500/30">
                      <div className="text-sm text-yellow-300 mb-1">Largest Nail</div>
                      <div className="text-lg font-bold text-yellow-400">
                        {measurementStats.largestNail.finger}
                      </div>
                      <div className="text-xs text-yellow-300">
                        {measurementStats.largestNail.area.toFixed(1)} mm²
                      </div>
                    </div>
                  )}

                   <div className="mt-4 p-3 bg-indigo-500/10 rounded-lg border border-indigo-500/20">
                    <div className="text-sm text-indigo-300 mb-2">📊 Professional Analysis:</div>
                    <div className="text-xs text-gray-400 space-y-1">
                      <div>• Hand width: {handWidthPixels.toFixed(0)} pixels (85mm calibrated)</div>
                      <div>• Calibration ratio: {calibratedRatio.toFixed(3)} mm/pixel</div>
                      <div>• Medical accuracy suitable for health monitoring</div>
                      <div>• Export data for comparative analysis</div>
                      <div>• Anatomically accurate nail proportions</div>
                      <div>• Adaptive sizing for various nail lengths</div>
                    </div>
                  </div>
                  
                  {/* Enhanced Calibration Controls */}
                  <div className="mt-4 p-3 bg-emerald-500/10 rounded-lg border border-emerald-500/20">
                    <div className="text-sm text-emerald-300 mb-3">🎯 Calibration Assistant:</div>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-400">Manual Ratio Adjustment:</span>
                        <input
                          type="range"
                          min="0.1"
                          max="0.5"
                          step="0.01"
                          value={pixelToMmRatio}
                          onChange={(e) => setPixelToMmRatio(Number(e.target.value))}
                          className="w-24 h-2 bg-gray-700 rounded-lg"
                        />
                      </div>
                      <div className="text-xs text-gray-500">
                        Current: {pixelToMmRatio.toFixed(3)} mm/pixel
                      </div>
                      <button
                        onClick={() => setCalibratedRatio(pixelToMmRatio)}
                        className="w-full text-xs bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 py-1 px-2 rounded border border-emerald-600/30 transition-colors"
                      >
                        Apply Manual Calibration
                      </button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Virtual Nail Art Tools */}
            <VirtualNailArt
              canvasRef={canvasRef}
              detectedNails={detectedNails}
              onSaveDesign={handleSaveDesign}
              onDesignChange={handleDesignChange}
            />

            {/* Design Gallery */}
            <DesignGallery
              savedDesigns={savedDesigns}
              onDeleteDesign={handleDeleteDesign}
              onDownloadDesign={handleDownloadDesign}
            />
          </div>
        </div>

        {/* Technical Info */}
        <Card className="bg-white/10 backdrop-blur-lg border-white/20">
          <CardHeader>
            <CardTitle className="text-white">Technical Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-300">
              <div>
                <h4 className="font-semibold text-white mb-2">MediaPipe Features:</h4>
                <ul className="space-y-1">
                  <li>• Real-time hand tracking</li>
                  <li>• 21 hand landmarks</li>
                  <li>• Multi-hand detection</li>
                  <li>• High accuracy tracking</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-white mb-2">Nail Art Features:</h4>
                <ul className="space-y-1">
                  <li>• Virtual polish application</li>
                  <li>• Multiple design patterns</li>
                  <li>• Live preview system</li>
                  <li>• Design save & gallery</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-white mb-2">Applications:</h4>
                <ul className="space-y-1">
                  <li>• Nail art design</li>
                  <li>• Virtual try-on</li>
                  <li>• Beauty analysis</li>
                  <li>• AR applications</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default NailDetectionDemo;
