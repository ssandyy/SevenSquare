
import NailDetectionDemo from "@/components/NailDetectionDemo";

const Index = () => {
  return <NailDetectionDemo />;
};

export default Index;
